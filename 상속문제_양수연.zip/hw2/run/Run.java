package com.hw2.run;

import com.hw2.model.Circle;
import com.hw2.model.Rectangle;

public class Run {

	public static void main(String[] args) {
		//1. 크기가 2개인 circle, Rectangle 객체 배열 생성
		Circle[] c = new Circle[2];
		Rectangle[] r = new Rectangle[2];
		
		//2. 값 할당
		c[0] = new Circle(1, 2, 3);
		c[1] = new Circle(3, 3, 4);
		
		System.out.println("===== circle =====");
		for(Circle c1 : c) {
			c1.draw();
		}
		
		r[0] = new Rectangle(-1, -2, 5, 2);
		r[1] = new Rectangle(-2, 5, 2, 8);
		
		System.out.println("===== rectangle =====");
		for(Rectangle r1 : r) {
			r1.draw();
		}

	}

}
