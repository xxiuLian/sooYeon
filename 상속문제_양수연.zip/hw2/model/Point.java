package com.hw2.model;

public class Point {

	//필드
	private int x;
	private int y;
	
	public Point() {
		// TODO Auto-generated constructor stub
	}
	
	
	//생성자
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	//getter/setter
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	//메소드
	public void draw() {
		System.out.printf("(x, y) : (%d, %d)\n", x, y);
	}
	
	
}