package com.hw1.run;

import java.util.Scanner;

import com.hw1.model.Employee;
import com.hw1.model.Student;

public class Run {

	public static void main(String[] args) {
		//1. 3명의 학생 정보를 기록할 수 있게 객체 배열을 할당 
		Student[] stu = new Student[3];
		
		//2. 3명의 학생 객체 생성 후 반복문을 통해 출력
		stu[0] = new Student("홍길동", 20, 178.2, 70, 1, "정보시스템공학과");
		stu[1] = new Student("김말똥", 21, 187.3, 80, 2, "경영학과");
		stu[2] = new Student("강개순", 23, 167, 45, 4, "정보통신공학과");
		
		for(int i = 0; i < stu.length; i++) {
			System.out.println(stu[i].information());
		}
		
		//1. 최대 10명의 사원 정보를 기록할 수 있게 객체 배열을 할당
		Employee[] emp = new Employee[10];
		
		//2. 키보드로 사원 정보를 입력 받도록 구현
		Scanner sc = new Scanner(System.in);
		
		//emp index 담을 변수 선언
		int count = 0;
		
		while(true) {
			
			System.out.println("==사원 정보 입력==");
			System.out.print("이름 : ");
			String name = sc.nextLine();
			System.out.print("나이 : ");
			int age = sc.nextInt();
			System.out.print("신장 : ");
			double height = sc.nextInt();
			System.out.print("몸무게 : ");
			double weight = sc.nextDouble();
			System.out.print("급여 : ");
			int salary = sc.nextInt();
			sc.nextLine();
			System.out.print("부서 : ");
			String dept = sc.nextLine();
			
			Employee em = new Employee(name, age, height, weight, salary, dept);
			
			emp[count++] = em;
			
			System.out.println("추가하시겠습니까?(y/n) ");
			char answer = sc.nextLine().toLowerCase().charAt(0);
			
			if(answer == 'n') {
				break;
			}
		}//while
		
		for(int i = 0; i < count; i++) {
			System.out.println(emp[i].information());
			
		}
		
	}
	
	
}

