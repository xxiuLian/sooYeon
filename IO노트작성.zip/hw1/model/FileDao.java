package com.hw1.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileDao {

	Scanner sc = new Scanner(System.in);
	
	
	public FileDao() {}
	
	public void fileSave() {
		
		StringBuilder sb = new StringBuilder();
		
		System.out.println("파일에 저장할 내용을 반복해서 입력하시오 (" + "exit" + "을 입력하면 내용 입력 끝) : ");
		
		while(true) {

		// 값을 Scanner로 입력 받고 해당 입력 값이 “exit”일 경우 반복문 빠져나감
			String memo = sc.nextLine();
			
			if(memo.equals("exit")) break; //exit입력하면 while빠져나가기
			else sb.append(memo);  //sb += memo; 이렇게 썼다가 에러남 append 써야함 왜 stringbuilder에 넣으려면 append사용이 원칙
		// 아닐 경우 sb에 추가
			
		}
		
		// “저장하시겠습니까? (y/n)”
		System.out.println("저장하시겠습니까? (y/n)");
		char answer = sc.nextLine().toLowerCase().charAt(0);
		
		// 입력 받은 값이 대문자이든 소문자이든 상관없이 “y”이면,
		// 저장할 파일명을 입력 받음
		if(answer == 'y') {
			System.out.println("저장할 파일명을 입력하시오 : ");
			String fileName = sc.nextLine();
			
		//기반스트림 생성 (어떤 외부매체와 데이터를 주고받을 것이냐를 선택해주는 메인(기반) 스트림이 반드시 필요.
			BufferedWriter bw = null;
			
			try {
				
				bw = new BufferedWriter(new FileWriter(fileName + ".txt"));
				//bw.write(버퍼에 넣을 데이터)
				bw.write(sb.toString()); //memo담아준 sb 호출 toString : 현재 문쟈열을 String형으로 반환한다는 뜻
				
				//다 담아줬으면 마무리 멘트~~~~~~~~~~~
				System.out.println(fileName + ".txt 파일에 성공적으로 저장하였습니다.");// 이제 스트림 닫으러 가기
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				
				if(bw != null) //bw가 채워졌으면, 값이 있으면
					try {
						bw.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 		
			}//finally 
			
		}else { // 입력 받은 값이 y가 아니면 “다시 메뉴로 돌아갑니다.” 출력하고 메뉴로
			System.out.println("다시 메뉴로 돌아갑니다."); return; //리턴 : 끝내기 끝내면 run으로 돌아감
			
		}
		
		
	}
	
	

	public void fileOpen() {
		// “열기 할 파일명 : “
		System.out.println("열기 할 파일명 : ");
		String fileName = sc.nextLine();
		
		// 파일명을 Scanner로 입력 받아, BufferedReader와 FileReader 스트림 사용
		try (BufferedReader br = new BufferedReader(new FileReader(fileName + ".txt"))) {
			
			// try구문 안에서 readLine()메소드를 통해 한줄씩 콘솔로 입력받은 값 출력
			//파일 읽은거 담을 변수
			String temp = null;
			//null이 아닐때까지 계속 값 읽기
			while((temp = br.readLine()) != null) {
				
				System.out.println(temp);
			}
			
		} catch (FileNotFoundException e) {
			// 존재하지 않은 파일 명 입력했을 때 해당 예외처리구문이 실행됨
			// “존재하는 파일이 없습니다.”
			System.out.println("존재하는 파일이 없습니다.");
			return; //return 안써주면 run으로 돌아갈때 에러 오지게 뜸
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	public void fileEdit() {
		System.out.println("수정 할 파일명 : ");
		String fileName = sc.nextLine();
		
		// 파일명을 입력받아 BufferedReader와 BufferedWriter, FileReader와 FileWriter스트림 사용
		BufferedReader br = null;
		BufferedWriter bw = null;
		StringBuilder sbEdit = new StringBuilder(); //추가되는 내용 받을 변수
		
				
		try {
			//파일 먼저 읽기
			br = new BufferedReader(new FileReader(fileName + ".txt"));
			
			//파일 넣기 기존 파일에 추가로 붙여넣는것이기 때문에 ,true 요거요거 꼭 써야함
			bw = new BufferedWriter(new FileWriter(fileName + ".txt", true));
			
			
			//fileOpen에서 했던 것처럼 쓰기
			//////////1. 수정할 파일 가져오기
			String temp = null;
			
			while((temp = br.readLine()) != null) {
				System.out.println(temp);
			}
			
			//////////2. 추가할 내용 작성
			System.out.println("파일에 추가할 내용을 입력하세요 : ");
			
			while(true) {
				
				String memo = sc.nextLine();
				
				if(memo.equals("exit")) { //exit입력받으면 break;
					break;
				}else {//객체 bw에 append()사용해서 붙이기
					bw.append(memo);
				}
				
			}
			
			
			//////////3. 파일 저장
			System.out.println("변경된 내용을 파일에 추가하시겠습니까? (y/n) ");
			char answer = sc.nextLine().toLowerCase().charAt(0);
			
			if(answer == 'y') { //오키 추가
				bw.write(sbEdit.toString());//추가!
				System.out.println("입력받은 " + fileName +".txt 파일의 내용이 변경되었습니다.");
			} else {
				System.out.println("다시 메뉴로 돌아갑니다.");
				return; //메소드 끝내기
			}
			
			
		} catch (FileNotFoundException e) {
			System.out.println("존재하는 파일이 없습니다.");
			return;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			//br, bw스트림 닫기
			if (br != null)
				try {
					br.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			if (bw != null)
				try {
					bw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
				
				
	}
}
