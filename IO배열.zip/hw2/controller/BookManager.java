package com.hw2.controller;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

import com.hw2.model.Book;

public class BookManager {
	
	Scanner sc = new Scanner(System.in);
	
	public BookManager() {
		//기본생성자
	}
	
	//5가지 도서에 대한 정보를 객체배열과 Object스트림을 통해 파일에 저장하는 메소드
	public void fileSave() {
		
		Book[] bk = new Book[5]; // Book객체를 받을 객체 배열
		
		//Book클래스의 dates 자료형 stirng으로 변경 !!!!!!가이드 확인하기!!!!!!
		bk[0] = new Book("C언어", "김씨", 10000, setCalendar(2012, 2, 2), 0.1);
		bk[1] = new Book("자바", "이씨", 20000, setCalendar(2013, 3, 3), 0.2);
		bk[2] = new Book("C++", "박씨", 30000, setCalendar(2014, 4, 4), 0.3);
		bk[3] = new Book("넛지", "서씨", 40000, setCalendar(2015, 5, 5), 0.4);
		bk[4] = new Book("개미", "최씨", 50000, setCalendar(2016, 6, 6), 0.5);
	
		//try with resource 구문으로 “books.dat”파일에 저장되게 
		//ObjectOutputStream과 (보조스트림)
		//FileOutputStream을 (기반스트림) 생성 -->finally로 스트림닫기 필요없음
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("books.dat"))) {
			
			//ObjectOutputStream은 writeObject()로 bk불러오기!
			for(int i = 0; i < bk.length; i++) {
				oos.writeObject(bk[i]);
				//직렬화과정에서 처리 필요할때 writeObject랑readObject사용함
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	
	}

	public String setCalendar(int year, int month, int date) {
		//캘린더 객체 생성
		//Calendar cal = new Calendar();//에러..왜? Calendar는 추상클래스라서 객체 직접생성 불가능
		//메소드를 통해 구현된 클래스 인스턴스를 얻어야함
		Calendar cal = Calendar.getInstance();
		
		//날짜 담아주기
		cal.set(year, month-1, date);
		
		//날짜데이터 원하는 형태로 출력
		SimpleDateFormat df = new SimpleDateFormat("yyyy년 mm월 dd일");
		
		//출력하고자 하는 문자열로 format() 문자열에 담기
		String calendar = df.format(cal.getTime());
		
		return calendar; //여기서 String으로 변환하라고,,,해줌
	}
	
	
	//파일로부터 도서에 대한 정보를 불러와서 콘솔에 출력하는 메소드
	public void fileRead() {
		
		Book[] readBook = new Book[10];
		
		// try with resource 구문 
		//(FileNotFoundException과 ClassNotFoundException, EOFException, IOException 처리)
		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("books.dat"))) {
			
			// 반복문을 통해 값을 다 읽어 들인 후 “books.dat 읽기 완료!” 출력
			//String book = null;을 통해 받으려고 했지만 실패 -> String 허용X

			int index = 0;
			//readBook[0]부터 "books.dat"넣고 null값 될때까지 빼기
			while((readBook[index] = (Book)ois.readObject()) != null) {
				//readBook에 옮겨담은 books.dat 읽기~
				System.out.println(readBook[index].toString());
			}
			
//				int index = 0;
//				while(true) {
//					readBook[index] = (Book)ois.readObject();
//					System.out.println(readBook[index].toString());
//					index++;
//				}
			
		//catch 문구 순서는 상관X
		} catch (FileNotFoundException  e) {
			e.printStackTrace();
		} catch (EOFException e) {
				//e.printStackTrace();밑에 오류출력문구랑 같이 존재하지 X 오류남!!!!!!오류원인찾음
				System.out.println("books.dat 읽기 완료!");//더이상 읽어들일 파일이 없을때 파일 다읽고 마지막에 출력
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	

}
