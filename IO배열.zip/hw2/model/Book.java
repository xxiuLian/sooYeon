package com.hw2.model;

import java.io.Serializable;

public class Book implements Serializable {
	/*
	 * Book 뒤에 implements Serializable쓰고 Book마우스 올리면 다음과 같이 시리얼아이디 추가할 수 있음
	 * 
	 * 객체는 문자 아님 -> 바이트 기반 스트림으로 데이터 변경해주는 직렬화(Serializable)필수임ㅠ -> 직렬화된 객체만 사용가능 
	 */
	private static final long serialVersionUID = 1L;
	private String title;
	private String author;
	private int price;
	private String dates;
	private double discountRate;
	
	public Book() {
		//기본생성자
	}
	//5개의 초기값을 받는 매개변수 생성자
	public Book(String title, String author, int price, String dates, double discountRate) {
		this.title = title;
		this.author = author;
		this.price = price;
		this.dates = dates;
		this.discountRate = discountRate;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getDates() {
		return dates;
	}

	public void setDates(String dates) {
		this.dates = dates;
	}

	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	@Override
	public String toString() {
		return title + " " + author + " " + price + " " + dates + " 출간 "
				+ discountRate;
	}
	
}

