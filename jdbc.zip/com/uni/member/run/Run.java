package com.uni.member.run;

import com.uni.member.view.MemberMenu;

public class Run {

	public static void main(String[] args) {
		new MemberMenu().mainMenu();

	}

}
