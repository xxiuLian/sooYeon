package com.mvc.controller;

import java.util.ArrayList;

import com.mvc.model.vo.Book;

public class BookManager {
	
	ArrayList<Book> bookList = new ArrayList<Book>();

	public void insertBook(Book book) {
		// 전달 받은 book은 현재 도서 번호가 0인 채로 들어오는데 새로운 도서가 추가될 때마다 추가되는 도서의 도서 번호는
		// 리스트 마지막 도서 번호의 다음 번호로 부여해야 됨
		int lastNo = 0; // 우선 변수 생성 및 초기화
		
		try {

			lastNo = bookList.get(bookList.size()-1).getbNo() + 1; // 마지막 도서 번호 + 1
			
			//lastNo를 0부터 값을 넣으면 -1이됨
		} catch(IndexOutOfBoundsException e) {
			lastNo = 1;//1로 임의변경
		}
		
		book.setbNo(lastNo); //book bNo는 lastNo!
		
		bookList.add(book);

	}

	public int deleteBook(int bNo) {
		
		// for문을 이용하여 전달받은 도서 번호가 존재하는 도서 삭제
		// 성공적으로 삭제 할 경우 1 리턴
		// 삭제 되지 않은 경우 즉, 존재하는 도서 번호가 없는 경우 0 리턴
		int result = 0;   //-->리턴 값 
		
		//값이 무조건 있다는 전제 하에(일반for문사용)
		//ArrayList는 .size() -- .length(X)
		for(int i = 0; i < bookList.size(); i++) {
			//bookList.get(i)로 리스트 반복 -- bookList[i](X)
			if(bookList.get(i).getbNo() == bNo) {
				bookList.remove(i);//해당 bNo삭제
				result = 1;
			}
		}
		return result;
	}

	public ArrayList<Book> searchBook(String title) {
		ArrayList<Book> searchList = new ArrayList<Book>(); // 검색 결과값들을 보관할 리스트
		// for문을 이용하여 전달받은 제목을 포함한 도서를 searchList에 추가
		
		for(Book b : bookList) {
			//book의 제목이 입력받은 title이랑 같으면
			if(b.getTitle().contains(title)) {
				searchList.add(b); //searchList에 추가해라
			}
		}
		// searchList 리턴
		return searchList;
	}

	public ArrayList<Book> selectList() {
		
		return bookList; //bookList.toString이라 해서 오류 리턴 걍 bookList로만 리턴!!
	}
	
	

}
