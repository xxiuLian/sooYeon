package com.mvc.run;

import com.mvc.view.BookMenu;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new BookMenu().mainMenu();
	}

}
