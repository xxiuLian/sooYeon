package com.mvc.view;

import java.util.ArrayList;
import java.util.Scanner;

import com.mvc.controller.BookManager;
import com.mvc.model.vo.Book;

public class BookMenu {

	private Scanner sc = new Scanner(System.in);
	private BookManager bm = new BookManager();
	
	public BookMenu() {
		//기본생성자
	}
	
	
	//메소드
	public void mainMenu() {
		
		while(true) {//메뉴 화면 반복실행 무한루프처리~
			System.out.println("*** 도서 관리 프로그램 ***");
			System.out.println("1. 새 도서 추가");
			System.out.println("2. 도서 삭제");
			System.out.println("3. 도서 검색 출력");
			System.out.println("4. 전체 출력");
			System.out.println("0. 끝내기");
			System.out.println("메뉴 번호 선택 : ");
			int menu = sc.nextInt();
			sc.nextLine();
			
			switch(menu) {
			case 1 :
				insertBook();
				break; //1번실행하고 switch문 빠져나가기 -> 21행
			case 2 :
				deleteBook();
				break; //2번실행하고 21행
			case 3 :
				searchBook();
				break; //3번실행하고 21행
			case 4 :
				selectList();
				break; //4번실행하고 21행
			case 0 :
				System.out.println("프로그램 종료");
				return; //0번실행하고 끝!
			default :
				System.out.println("잘못 누르셨습니다.");
				break;
			}
					
		}

		
	}

	//제목, 카테고리, 저자명을 키보드로 입력 받고 입력 받은 값을 가지고 Book객체 생성
	//생성한 Book 객체를 BookManager의insertBook 메소드로 전달
	public void insertBook() {
		
		System.out.println("도서 제목 : ");
		String title = sc.nextLine();
		System.out.println("도서 장르 (1:인문 / 2:자연과학 / 3:의료 / 4:기타) : ");
		int category = sc.nextInt();
		sc.nextLine();
		System.out.println("도서 저자 : ");
		String author = sc.nextLine();
		
		Book book = new Book(title, category, author);
		
		bm.insertBook(book);
		System.out.println(book.toString());
		
	}
	
	
	// BookManager의 deleteBook 메소드로 bNo 전달
	// 리턴 값 전달 받음 (result)
	public void deleteBook() {
		
		System.out.println("도서 번호 : ");
		int bNo = sc.nextInt();
		
		int result = bm.deleteBook(bNo);
		// result가 1일 경우 >> “성공적으로 삭제” 출력
		// result가 0일 경우 >> “삭제할 도서가 존재하지 않습니다.”출력
		if(result == 1) {
			System.out.println("성공적으로 삭!제!!");
		}else {
			System.out.println("삭제할 도서가 존재하지 않습니다.");
		}
		
		
	}
	
	
	public void searchBook() {
		// “도서 제목 : “ >> 입력 받음 (title)
		System.out.println("도서 제목 : ");
		String title = sc.nextLine();
		
		// BookManager의 searchBook 메소드로 title 전달
		ArrayList<Book> searchList = bm.searchBook(title);
		
		// 리턴 값 전달 받음 (searchList)
		// searchList가 비어 있을 경우 >> “검색 결과가 존재하지 않습니다.”출력
		// searchList가 비어있지 않을 경우 >> for문을 이용하여 searchList 출력
		//!!!모든 Object 타입(Integer, String, ArrayList, ...)은 heap 영역에 생성된다.
		if(searchList != null) { //그래서 searchList = null;이라고 초기값을 주지 않아도 알아서 없으면 null로 반환 에러가 안났음
								//ArrayList에서 값 유무 확인할때 .isEmpty()를 사용
			for(Book b : searchList) {
				System.out.println(b.toString());
			}
		}else {
			System.out.println("검색 결과가 존재하지 않습니다.");
		}

		
	}
	
	
	public void selectList() {
		
		// BookManager의 selectList() 메소드 호출
		//타입을 String으로 써서 오류;;;,,,, bookList 타입은 String이 아니라 ArrayList<Book>임!!!
		ArrayList<Book> bookList = bm.selectList();
		// 리턴 값 전달 받음 (bookList)
		
		// bookList가 비어 있을 경우 >> “도서 목록이 존재하지 않습니다.”출력
		// bookList가 비어있지 않을 경우 >> for loop문을 이용하여 bookList 출력 또는 for each 문 이용하여 출력

		if(bookList.isEmpty()) {
			System.out.println("도서 목록이 존재하지 않습니다.");
			
		}else {
			for(Book b : bookList) {
				System.out.println(b.toString());
			}
		}
		
		
	}
	
	
	
	
	
	
}
