package com.kh.collection.silsub1.model.dao;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import com.kh.collection.silsub1.model.vo.Board;

public class BoardDao {
	
	private ArrayList<Board> list = new ArrayList<Board>();
	
	//1. 파일 읽어들이기 빼내오기 (IO에서 입력)
	public void BoardDao() {
		//기본 생성자 board_list.dat 파일의 내용을 읽어서 list에 저장함 null 될 때까지 저장함
		//ObjectInputStream ois = new ObjectInputStream(new FileInputStream("board_list.dat"));
		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("board_list.dat"));) {
			
			//1번 saveListFile()에서 for문 사용해 Board객체 하나씩 넣기
//			Board b;
//			while((b=(Board)ois.readObject()) != null) {
//				list.add(b);
//			}
			//2번 상기와 동일, while무한루프 돌지만 끝을 만나면 EOFException발생 catch에서 return;
			while(true) {
				list.add((Board)ois.readObject());
			}
			//3번 saveListFile()에서 addAll()이용해 ArrayList 통째로 저장하기
			//list.addAll((Array<Board>)ois.readObject());
			
			
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		} catch (ClassNotFoundException e) {

			System.out.println("파일을 찾을 수 없습니다.");
		}
		
	}
	
	
	//게시물 마지막 번호 알아내기 위한 메소드
	public int getLastBoardNo() {
		
		return list.get(list.size()-1).getBoardNo();
		
	}
	
	
	//1. 게시글 쓰기!!!!전달받은 게시글을 list에 추가
	public void writeBoard(Board board) {
		
		list.add(board);
		
	}
	
	
	//2. 게시글 전체 보기
	public ArrayList<Board> displayAllList() {
		
		return list;
	}

	//3. 게시글 한개 보기
	public Board displayBoard(int num) {
		
		Board board = null;
		
		for(int i = 0; i < list.size(); i++) { //for문 Book Board list(객체쓰)에 게시글 번호 확인 
			if(list.get(i).getBoardNo() == num) { //사용자가 입력했던 번호랑 일치하는게 있다면
				
				board = list.get(i);
				break;
			}
		}
		return board;
	}


	//4. 게시글 조회수 올리기
	public void upReadCount(int num) {
		
		for(int i = 0; i < list.size(); i++) {
			if(list.get(i).getBoardNo() == num) {
				//기존의 조회수 + 1 왜? 읽었으니까
				list.get(i).setReadCount(list.get(i).getReadCount() + 1);
				break;
			}
		}
	}

	
	//5. 게시글 제목 수정하기
	public void modifyTitle(int num, String title) {
		//전달받은 글 번호와 일치하는 게시글의 제목을 수정하기
		for(int i = 0; i < list.size(); i++) {
			if(list.get(i).getBoardNo() == num) {
				list.get(i).setBoardTitle(title);
				break;
			}
		}
	}
	
	
	//6. 게시글 내용 수정하기 (5번이랑 동일 구성)
	public void modifyContent(int num, String content) {
		//전달받은 글 번호와 일치하는 게시글의 내용을 수정하기
		for(int i = 0; i < list.size(); i++) {
			if(list.get(i).getBoardNo() == num) {
				list.get(i).setBoardContent(content);
				break;
			}
		}
	}

	
	//7. 게시글 삭제
	public void deleteBoard(int num) {
		//전달받은 글 번호와 일치하는 게시글 삭제

		for(int i = 0; i < list.size(); i++) {
			if(list.get(i).getBoardNo() == num) {
				list.remove(i);
				
			}
		}	
	}

	//8. 게시글 검색 후 해당 게시글 출력
	public ArrayList<Board> searchBoard(String title) {
		//전달받은 제목이 포함되어있는 게시글들 list 리턴
		//1. ArrayList에서 찾을 게시글들 담아줄 ArrayList 초기화
		ArrayList<Board> searchList = new ArrayList<Board>();
		
		for(int i = 0; i < list.size(); i++) {
			if(list.get(i).getBoardTitle().contains(title)) {
				//입력받은 제목이랑 같으면 searchList에 챱 챱 붙이기.add()사용!
				searchList.add(list.get(i));
				//읽었구나? 조회수 올려
				list.get(i).setReadCount(list.get(i).getReadCount() + 1);//(해당 글의 현재 조회수 + 1);
			}
		}
		return searchList;
	}


	//9. 파일에 저장하기 (IO에서 출력)
	public void saveListFile() {
		
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("board_list.dat"))){
			
			System.out.println(list);
			oos.writeObject(list);
			
			System.out.println("파일에 성공적으로 저장되었습니다.");
			
			oos.close();
			
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
	
	
	
}
