package com.kh.collection.silsub1.model.comparator;

import java.util.Comparator;

import com.kh.collection.silsub1.model.vo.Board;

public class AscBoardDate implements Comparator<Board> {

	@Override
	public int compare(Board o1, Board o2) {
		//숫자 오름차순 12345
		//o1(인덱스 앞) - o2(인덱스 뒤) = 1 
		//==>양수, 바꾸기 왜? 크면 뒤로 가야하니까
		//compareTo 음수면 -1, 양수면 1반환
		return o1.getBoardDate().compareTo(o2.getBoardDate());
	}
}
