package com.kh.collection.silsub1.model.comparator;

import java.util.Comparator;

import com.kh.collection.silsub1.model.vo.Board;

public class DescBoardDate implements Comparator <Board> {

	@Override
	public int compare(Board o1, Board o2) {
		//숫자 내림차순 54321
		//o2(인덱스 뒤) - o1(인덱스 앞) = -1 
		//==>음수, 바꾸기 왜? 작으면 뒤로 가야하니까
		//compareTo 음수면 -1, 양수면 1반환
		return o2.getBoardDate().compareTo(o1.getBoardDate());
	}
}
