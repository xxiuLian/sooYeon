package com.kh.collection.silsub1.model.comparator;

import java.util.Comparator;

import com.kh.collection.silsub1.model.vo.Board;

public class AscBoardNo implements Comparator /* <Board> */{

	@Override
	public int compare(Object o1, Object o2) {
		if(o1 instanceof Board && o2 instanceof Board) {
			Board b1 = (Board) o1;
			Board b2 = (Board) o2;
			//숫자 오름차순 12345
			//o1(인덱스 앞) - o2(인덱스 뒤) = 1 
			//==>양수, 바꾸기 왜? 크면 뒤로 가야하니까
			return b1.getBoardNo() - b2.getBoardNo();//내림차순
		}
		
		return 0;
	}
	
	
	/*@Override
	public int compare(Board b1, Board b2) {
		return b1.getBoardNo()- b2.getBoardNo();
	}*/

}
