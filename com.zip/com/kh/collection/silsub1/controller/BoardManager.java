package com.kh.collection.silsub1.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

import com.kh.collection.silsub1.model.comparator.AscBoardDate;
import com.kh.collection.silsub1.model.comparator.AscBoardNo;
import com.kh.collection.silsub1.model.comparator.AscBoardTitle;
import com.kh.collection.silsub1.model.comparator.DescBoardDate;
import com.kh.collection.silsub1.model.comparator.DescBoardNo;
import com.kh.collection.silsub1.model.comparator.DescBoardTitle;
import com.kh.collection.silsub1.model.dao.BoardDao;
import com.kh.collection.silsub1.model.vo.Board;

public class BoardManager {
	
	private Scanner sc = new Scanner(System.in);
	private BoardDao bd = new BoardDao();
	
	public BoardManager() {
		// TODO Auto-generated constructor stub
	}

	public void writeBoard() {
		// "새 게시글 쓰기 입니다." 출력
		// "글 제목 : " >> 입력 받음 (공백 포함)
		// "작성자 : " >> 입력 받음 (공백 없이)
		System.out.println("새 게시글 쓰기입니다.");
		System.out.print("글 제목 : ");
		String title = sc.nextLine();
		System.out.print("작성자 : ");
		String writer = sc.nextLine();

		// 작성날짜는 현재 날짜로 처리함
		Date date = new Date();
		
		// "글 내용 : " >> 여러 줄로 입력 받음 >>"exit" 입력하면 입력종료
		System.out.println("글 내용 (exit 입력 시 종료) : ");
		String content = "";
		
		while(true) {
			String str = sc.nextLine(); //글 내용 입력받기~~
			if(str.equals("exit")) {
				break; // 사용자가 exit 입력하면 글 내용 종료! 
			}
			content += str + "\n"; //한줄 입력하고 엔터String 
			//content += str + "\n";에러 String content 밖에서 초기화하기
			
		}

		// 파일이 존재하지 않을 경우, 즉 첫 글 등록일 경우 예외 발생-->IndexOutofBoundsException
		// try catch문을 이용
		// 첫 글 등록시 게시물 번호 1로 지정
		// --->new Board(1, title, writer, date, content);
		// 첫 글 X, getlastBoardNo() 기존 게시물의 제일 마지막 번호를 불러와 +1
		// --->new Board(기본 게시물 마지막 번호 +1, title, writer, date, content);
		try {
			// BoardDao의 writeBoard() 메소드 호출 시 해당 Board 전달
			// BoardDao의 getLastBoardNo() 메소드를 통해 게시글의 마지막 번호를 알아옴
			bd.writeBoard(new Board(bd.getLastBoardNo() + 1, title, writer, date, content));
			
		} catch(IndexOutOfBoundsException e) {
			//첫 글일경우 0이라 에러남 게시물 번호 1로 지정
			bd.writeBoard(new Board(1, title, writer, date, content));
		}
		
		
	}
	
	//2. 게시글 전체 보기
	public void displayAllList() {
		// BoardDao의 displayAllList() 메소드를 호출하여 ArrayList를 전달받음
		// System.out.println(bd.displayAllList());
		
		// Iterator를 이용하여 list 에 기록된 정보를 모두 화면에 출력시킴
		Iterator it = bd.displayAllList().iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
	}
	
	
	//4. 게시글 조회수 올리기
	public void displayBoard() {
		System.out.println("조회할 글 번호 : ");
		int num = sc.nextInt();
		
		Board board = bd.displayBoard(num);
		
		if(board == null) { //실행 결과 일치하는 게시글이 없으면
			System.out.println("조회된 게시글이 없습니다.");
			
		}else {
			System.out.println(board); //게시글 조회~
			bd.upReadCount(num); //게시글 읽었으니까 조회수 올리기 조회된 게시글 번호를 넘김!!
		}

	}
	
	
	//5. 게시글 제목 수정하기
	public void modifyTitle() {
		System.out.print("수정할 글 번호 : ");
		int num = sc.nextInt();
		sc.nextLine();//버퍼 비우기!!!!!!!!!
		// BoardDao의 displayBoard() 메소드에 글 번호를 전달하여
		Board board = bd.displayBoard(num);


		// “변경할 글 제목 : “ >> 입력 받음
		if (board == null) {
			System.out.println("조회된 글이 없습니다.");
		} else {
			//해당 글 번호의 게시글 전달 받아 출력하고
			System.out.println(board);
			
			System.out.print("변경할 제목 : ");
			String title = sc.nextLine();
			// BoardDao의 modifyTitle() 메소드에 해당 글 번호와 변경할 제목 전달
			bd.modifyTitle(num, title);
		}
	}

	//6. 게시글 내용 수정하기 (5번이랑 동일한 구성)
	public void modifyContent() {
		// 위의 modifyTitle() 메소드 구현 내용과 동일 >> title을 content로만 변경
		System.out.print("수정할 글 번호 : ");
		int num = sc.nextInt(); 
		sc.nextLine();//버퍼 비우기!!!!!!!!!
		// BoardDao의 displayBoard() 메소드에 글 번호를 전달하여
		Board board = bd.displayBoard(num);

		// “변경할 글 제목 : “ >> 입력 받음
		if (board == null) {
			System.out.println("조회된 글이 없습니다.");
		} else {
			//해당 글 번호의 게시글 전달 받아 출력하고
			System.out.println(board);
			
			System.out.print("변경할 내용 : ");
			String content = sc.nextLine();
			// BoardDao의 modifyTitle() 메소드에 해당 글 번호와 변경할 내용 전달
			bd.modifyTitle(num, content);
		}
	}
	
	
	//7. 게시글 삭제
	public void deleteBoard() {
		
		// “삭제할 글 번호 : “ >> 입력 받음
		System.out.print("삭제할 글번호 : ");
		int num = sc.nextInt();
		sc.nextLine();//버퍼 비우기
		// BoardDao의 displayBoard() 메소드를 호출하여 해당 글 번호의 게시글 전달 받아 출력(151행)
		Board board = bd.displayBoard(num);
		
		if (board == null) {
			// 만약 없을 경우 “조회된 글이 없습니다.” 출력
			System.out.println("조회된 글이 없습니다.");
		} else {
			System.out.println(board);
			// 있을 경우 “정말로 삭제하시겠습니까? (y/n) : “ >> 입력 받음
			// 대소문자 관계없이 Y 일 경우 BoardDao의 deleteBoard() 메소드에 해당 글 번호 전달
			System.out.print("정말로 삭제하시겠습니까? (y/n) : ");
			char ch = sc.nextLine().toUpperCase().charAt(0);
			if (ch == 'Y') {
				bd.deleteBoard(num); //글 번호 확인
				System.out.println(num + "번 글이 삭제되었습니다.");
			}
		}

		
	}
	
	
	//8. 게시글 검색 후 해당 게시글 출력
	public void searchBoard() {
		// “검색할 제목 : “ >> 입력 받음
		System.out.print("검색할 제목 : ");
		String title = sc.nextLine();

		// BoardDao의 searchBoaard() 메소드에 입력 값 전달
		// 제목은 중복될 수 있기 때문에-->결과가 1개이상 일 수 있으니까 결과값 다중 list로 결과값 전달받음
		ArrayList<Board> searchList = bd.searchBoard(title);
		// 결과값이 없으면 “검색 결과가 없습니다.” 출력
		if(searchList.isEmpty()) { //List에서 null인지 참거짓판별해줌
			System.out.println("검색 결과가 없습니다.");
		}else {
			// 결과값이 있으면 list출력 searchList에 담긴애들 다 나와
			for(int i = 0; i < searchList.size(); i++) {
				System.out.println(searchList.get(i));
			}
		}
	}
	 
	//파일에 저장하기!!
	public void saveListFile() {
		// BoardDao의 saveListFile()의 메소드 호출
		bd.saveListFile();
		
	}
	
	
	/////////////////////// 게시글 정렬 //////////////////////////////

	public void sortList(int item, boolean isDesc) {
		// BoardDao의 displayAllList()의 메소드를 호출하여 전체 글 리스트 전달 받아
		// 전체 받으려면 Array에 받아버리기~
		ArrayList<Board> list = bd.displayAllList();
	
		// isDesc 가 true 이면 내림차순정렬 작동
		// isDesc 가 false 이면 오름차순정렬 작동되게 함
		switch(item) {
		// item 이 1이면 번호순 정렬
		case 1 :
			if(isDesc)
				
				list.sort(new DescBoardNo()); // bm.sortList(1, true);
			else
				list.sort(new AscBoardNo()); //bm.sortList(1, false);
			
		// item 이 2이면 날짜순 정렬
		case 2 :
			if(isDesc) 
				list.sort(new DescBoardDate());// bm.sortList(2, true);
			
			else
				list.sort(new AscBoardDate());// bm.sortList(2, false);
		// item 이 3이면 제목순 정렬 작동되게 정렬용 클래스 사용함
		case 3 :
			if(isDesc) 
				list.sort(new DescBoardTitle());// bm.sortList(3, true);
			
			else
				list.sort(new AscBoardTitle());// bm.sortList(3, false);
		
		}
		//출력!!
		for(int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
		
	}
		


}
