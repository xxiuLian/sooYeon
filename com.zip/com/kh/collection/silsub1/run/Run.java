package com.kh.collection.silsub1.run;

import com.kh.collection.silsub1.view.BoardMenu;

public class Run {

	public static void main(String[] args) {
		
		new BoardMenu().mainMenu();

	}

}
