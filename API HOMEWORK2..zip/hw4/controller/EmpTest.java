package com.hw4.controller;

import java.util.Scanner;

import com.hw4.model.Employee;

public class EmpTest {
	
	private Employee[] empArr = new Employee[6];
	private Scanner sc = new Scanner(System.in);
	
	public EmpTest() {}
	
	//크기가 6인 Employee[]을 만들고 위의 사용데이터에 나와 있는 순으로 
	//Employee[]에 저장 및 한 사원에 대한 이름, 나이, 급여, 세율을 입력 받고 저장
	public void setEmp() {
		
		empArr[0] = new Employee("김문말", 24, 1500000, 1.245);
		empArr[1] = new Employee("이장소", 40, 2500000, 1.4);
		empArr[2] = new Employee("박금순", 22, 1780000, 1.3);
		empArr[3] = new Employee("최봉호", 31, 1950000, 1.365);
		empArr[4] = new Employee("홍달림", 34, 1650000, 1.212);
		
		System.out.print("이름을 입력하세요 : ");
		String name = sc.nextLine();
		System.out.print("나이를 입력하세요 : ");
		int age = sc.nextInt();
		System.out.print("급여를 입력하세요 : ");
		int salary = sc.nextInt();
		System.out.print("세율을 입력하세요 : ");
		double tax = sc.nextDouble();
		
		//실제 급여 = 급여 – (급여 * 세율 / 100)
		empArr[5] = new Employee(name, age,(int)(salary-(salary*tax)/100), tax);
		
		
	}
	
	//Employee[] 출력
	public void printEmp() {
		
		for(int i = 0; i < empArr.length; i++) {
			
			System.out.println(empArr[i].toString());
		}
		
	}
	
	//정렬을 이용하여 이름을 기준으로 오름차순으로 출력
	public void nameSortPrint() {
		
		//사원 목록 여기다가 담고 정렬하고 뱉기
		Employee copy = new Employee();
		
		//정렬을 이용하여 이름을 기준으로 오름차순으로 출력(String에서 제공되는 compareTo() 활용)
		//기준값.compareTo(비교대상)
		//기준값이 비교대상보다 작은 경우 -1
		//기준값이 비교대상보다 큰 경우 +1 반환
		for(int i = 0; i < empArr.length; i++) {
			
			for(int j = i+1; j < empArr.length; j++) {
				//1이면!
				if(empArr[i].getName().compareTo(empArr[j].getName()) > 0) {
					copy = empArr[i];
					empArr[i] = empArr[j];
					empArr[j] = copy;
				}
			}
		}
		
	}
	
}
