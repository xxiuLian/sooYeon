package com.hw5.run;

import com.hw5.controller.NumberOk;

public class Run {


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		NumberOk no = new NumberOk();
		no.numGame();
	}

}
