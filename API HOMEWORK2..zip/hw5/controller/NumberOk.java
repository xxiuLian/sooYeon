package com.hw5.controller;

import java.util.Scanner;

public class NumberOk {


	private int ran;

	public NumberOk() {}


	//사용자에게 숫자를 입력 받고 입력 받은 숫자가 임의의 난수와 비교 했을 때 작은지 큰지,
	//몇 번 만에 맞추는지, 맞추면 계속 할지 끝낼지 묻는 메소드
	public void numGame() {
	
		//사용자에게 숫자 입력받기
		Scanner sc = new Scanner(System.in);
	
		//계속 할 지 물을 때 대답 받을 변수
		String str = "";
	
		while(true) { //무한루프
		
			int random = (int)(Math.random() * 100 + 1);
			System.out.println(random); //-> 정답 알고 시작하기~
		
			//사용자가 몇 번만에 맞추는지 카운트할 변수
			int i = 0;
		
			while(true) {
				i++; //한번 시작했으니까 1증가
				System.out.println("1부터 100사이의 정수를 하나 입력하세요 : ");
				int num = sc.nextInt();
				sc.nextLine(); //버퍼 비우기
				
				if(random < num) {
					System.out.println(num + "보다 작습니다." + i + "번째 실패!");
				}else if(random > num) {
					System.out.println(num + "보다 큽니다." + i + "번쨰 실패!");
				}else {
					System.out.println(i + "번만에 맞췄습니다!");//성공했으니 계속할건지 물어야함
					while(true) {
						System.out.println("계속 하시겠습니까?(y/n)");
						str = sc.nextLine();
						//equalsIgnoreCase("y")대소문자 구분하지 않고 비교
						if(str.equalsIgnoreCase("y")||str.equalsIgnoreCase("n"))
							break;//가까운while문빠져나감 -----> if 55행으로로 감 
						else
							System.out.println("잘못 입력하셨습니다. 다시 입력해주세요.");
							continue;//가까운while문다시재생-----> 44행으로로 감 
					}//else의 while
				}

					if(str.equalsIgnoreCase("y")) {
						System.out.println("새로운 게임을 시작합니다.");
						break;//가까운 while문(31행) 빠져나가기 -----> 랜덤숫자 25행으로 감
					} else if (str.equalsIgnoreCase("n")) {
						System.out.println("게임을 종료합니다");
						return;
					}
			}//while
			
		}//전체while
			
	}
}
