package com.hw6.run;

import com.hw6.controller.DateCalculator;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DateCalculator totalDay = new DateCalculator();
		
		System.out.println("총 날짜 수 : " + totalDay.leapDate());

	
	}

}

