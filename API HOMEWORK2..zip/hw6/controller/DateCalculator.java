package com.hw6.controller;

import java.util.Calendar;

public class DateCalculator {

	//XX
	public DateCalculator() {}
	
	//1년 1월 1일부터 오늘까지의 총 날수를 계산 1년부터 현재 연도까지
	//각 연도가 윤년이면 총 날수에 366일을, 평년이면 365일을 더함
	//해당 현재 연도가 윤년이면 2월을 29일로 평년이면 28일로 더함
	//월의 날짜 수를 더함 (31일: 1, 3, 5, 7, 8, 10, 12월/30일: 4, 6, 9, 11월)
	public long leapDate() {
		/* 
		  	=> 각 변수 선언 : 총 날수 저장용 => long sumDays = 0L;
		  	=> for loop 사용 : 1년 1월 1일부터 오늘까지의 총day를 계산함
		 
		  		  31일인 달(큰달) : 1, 3, 5, 7, 8, 10, 12월
		  		  30일인 달(작은달) : 4, 6, 9, 11월 
		  
		 */
			Calendar today = Calendar.getInstance();
			
			// total day를 저장할 변수
			long sumDays = 0L;
			
			for(int i = 1; i <= today.get(Calendar.YEAR); i++) {
					//윤년이라면 (366일더해야하니까) 										// Year
				if(i == today.get(Calendar.YEAR)){ 									// 올해가 되면
					if(isLeapYear(i)) System.out.println("올해는 윤년입니다.");
					//아니면 평년
					else System.out.println("올해는 평년입니다.");
					for(int j = 1; j <= (today.get(Calendar.MONTH)+1); j++){ 		// Month
																					// 이번달이 되면
						if( j== (today.get(Calendar.MONTH)+1)) {	
							
							for(int n = 1; n <= today.get(Calendar.DATE); n++) { 	// Date, 오늘이 되면
								sumDays += 1;
							}
							
						} else if(j == 2) {//윤년일때 2월은 29일이 있음
							if(isLeapYear(i)) sumDays += 29;
							else sumDays += 28;
							
						} else if(j == 4 || j == 6 || j == 9 || j == 11) {//4,6,9,11월은 30일까지 있음
							sumDays += 30;
							
						} else sumDays += 31; //나머지달 31일까지 있음
					}
				}
				else {
					if(isLeapYear(i)) sumDays += 366;
					else sumDays += 365;	
				}
			}
			return sumDays;
		}

	
	
	//연도가 윤년이면 true, 평년이면 false 리턴
	//(윤년: 연도가 4의 배수이면서, 100의 배수가 아니거나 400의 배수가 되는 해)
	public boolean isLeapYear(int year) {
//		 isLeapYear(년도) 구현 내용
//		 => 년도가 윤년이면 true, 평년이면 false 리턴함
		//연도가 4의배수이면서    100의 배수가 아니거나   400의 배수   -->윤년!!!!
		if(year % 4 == 0 && year % 100 != 0 || year % 400 == 0)
			return true;
		else return false;
		
	}
	
	
}