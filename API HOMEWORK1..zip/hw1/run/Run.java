package com.hw1.run;

import com.hw1.view.TokenMenu;

public class Run {

	public static void main(String[] args) {
		new TokenMenu().mainMenu();
	}

}
