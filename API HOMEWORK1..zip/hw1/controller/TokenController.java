package com.hw1.controller;

import java.util.StringTokenizer;

public class TokenController {

	//공백을 토큰 처리하고 글자 리턴
	public String afterToken(String str) {
		
		//토큰 처리하고 문자열(str)담을 변수 & 리턴할 값임..
		String result = "";
		
		//str에서 " "한칸 공백 없애기
		// StringTokenizer
		//: String(문자열)을 어떤 특수 기호를 기준으로 Token 단위로 나눠서 처리할때 쓰임
		// split 메소드와 유사하나 split 메소드를 쓰면 String 배열로 처리
		StringTokenizer st = new StringTokenizer(str, " ");//str을 어떤 토큰을 사용해서 처리할거?" "
		
		//" "한칸 공백 없어질때까지 무한루프
		while(st.hasMoreTokens()) {
			
			result += st.nextToken(); //공백뺀문자들을 result에 누적해서넣기
			
		}
		
		return result;
		
	}
	
	//입력받은 input 첫글자 대문자로~
	public String firstCap(String input) {
		
		//문자 분리하기 위해 뽑아내기 (J + avaprogram)
		String first = input.substring(0, 1); 	//substring(뽑을인덱스(시작), 뽑을인덱스(끝 다음)
												//substring(0,1) -> 0번째인덱스뽑는다는뜻
		String second = input.substring(1); 	//substring(1) ->1번째부터 끝까지 뽑기
		
		//first 대문자로
		first = first.toUpperCase();
		
		//다시 합치기
		return first + second;
		
		
	}
	
	//input에 one이라는 문자가 몇 개 있는지?
	public int findChar(String input, char one) {
		
		//one 개수 담을 정수 변수
		int sum = 0;
		
		for(int i = 0; i < input.length(); i++) {
			
			//one과 input비교
			if(one == input.charAt(i)) { //있다면 sum + 1
				sum++;
			}
		}
		
		return sum;
		
	}
	
	
	
	
	
}
