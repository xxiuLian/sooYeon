package com.hw3.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class SetDate {
	
	public SetDate() {
		// TODO Auto-generated constructor stub
	}
	
	public String todayPrint() {
		
		//시스템 시간 확인
		Calendar today = Calendar.getInstance();
		
		//오늘 년,월,일,시,분,초 각각 변수에 담기 --> String 으로 리턴
		int year = today.get(Calendar.YEAR);
		int month = today.get(Calendar.MONTH) + 1;  //왜 +1? month가 0월부터 시작됨
		int date = today.get(Calendar.DATE);
		int hour = today.get(Calendar.HOUR)  + 12; //오후 12시도 0시로 나오길래 더해줌
		int minute = today.get(Calendar.MINUTE);
		int second = today.get(Calendar.SECOND);
		
		return year + "년 " + month + "월 " + date + "일 " +
			   hour + "시 " + minute + "분 " + second + "초";
		
		
		Date today1 = new Date();
		System.out.println(today1);
		
	}
	
	
	
	public String setDay() {
		
		//“2011년 3월 21일 월요일”을 세팅하여 출력
		Calendar setTime = Calendar.getInstance();
		
		//setTime.set(int year, int month, int date);
		setTime.set(2011, 3-1, 21); //월(month)은 컴파일에서 +1되서 출력되기 떄문에 -1해줌, 아님 2라고 쓰거나
									//ex) 3월 --> 3-1+1=3
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일 E요일");
 		
		return sdf.format(setTime.getTime());
	}

}
