package practice3.controller;

import practice3.model.Animal;
import practice3.model.Cat;
import practice3.model.Dog;

public class AnimalManager {

	public static void main(String[] args) {
		// Animal 타입의 객체배열 크기 5로 생성
		Animal[] ani = new Animal[5];
		
		// 각 인덱스에 무작위로 Dog객체 또는 Cat객체로 생성
		ani[0] = new Dog("쫑이", "말티즈", 19);
		ani[1] = new Dog("제로", "비숑", 20);
		ani[2] = new Cat("먼지", "러시안블루", "영국", "회색");
		ani[3] = new Cat("구름", "페르시안", "페르시아", "회색");
		ani[4] = new Dog("뽀미", "푸들", 16);
		// (이때, 매개변수 생성자를 이용하여 생성)
		// 반복문을 통해서 해당 배열의 0번 인덱스부터 마지막 인덱스까지의
		// 객체의 speak() 메소드 호출
		for(Animal a : ani) {
			a.speak();
		}
	}

}
