package practice2.model;

public interface CellPhone extends Phone, Camera {

	public void charge();
	
}
