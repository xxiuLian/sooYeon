package practice2.model;

public abstract class SmartPhone implements CellPhone, TouchDisplay{

	public SmartPhone() {};
	
	public abstract void printMaker();
}
