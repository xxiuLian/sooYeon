package practice2.model;

public interface Camera {

	public void picture();
}
