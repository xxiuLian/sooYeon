package practice2.model;

public interface Phone {

	public void makeaCall();
	
	public void takeaCall();
	
	
}
