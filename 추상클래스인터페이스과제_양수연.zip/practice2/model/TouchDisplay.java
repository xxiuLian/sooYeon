package practice2.model;

public interface TouchDisplay {
	
	public void touch();

}
