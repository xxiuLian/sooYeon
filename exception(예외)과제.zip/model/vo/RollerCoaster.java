package com.hw1.model.vo;

public class RollerCoaster {

	//매 차례 한번에 110cm가 넘는 인원 2명을 태울 수 있는 놀이기구
	public static final double CUTHEIGHT = 110;
	public static final int PRICE = 4500; //1인당 4500
	public static final int PERMITNUMBER = 2;
	
	public RollerCoaster() {
		//기본생성자
	}

	@Override
	public String toString() {
		return "RollerCoaster [toString()=" + super.toString() + "]";
	}

	
	
}
