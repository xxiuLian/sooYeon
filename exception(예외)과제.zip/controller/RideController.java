package com.hw1.controller;

import com.hw1.model.vo.Guests;
import com.hw1.model.vo.RollerCoaster;

public class RideController {
	
	public RideController() {
		//기본생성자
	}
	
	//예외처리를 통해 인원을 제한하고 탑승자와 관련된 정보 출력
	public void cutGuests() {
		
		// 4명의 탑승 대기자를 생성자를 통한 Guest객체 배열 초기화 (Guests[] gs)
		Guests[] gs = new Guests[4];
		gs[0] = new Guests("홍길동", 17, 'M', 120.2);
		gs[1] = new Guests("유관순", 20, 'F', 102.3);
		gs[2] = new Guests("김유신", 23, 'M', 110.4);
		gs[3] = new Guests("김흥부", 21, 'M', 112.5);
		
		// RollerCoaster 클래스의 허용인원 상수값 크기의 또 다른 객체 배열 생성
		Guests[] onBoard = new Guests[RollerCoaster.PERMITNUMBER];
		
		// for문과 if문을 통해 RollerCoaster 클래스의 허용키 상수값 크기
		// 이상인 사람을 Guests객체 배열 onBoard에 담는다.
		
		//onBoard의 인덱스 번호를 맡을 변수
		int count = 0;
		try {
			for(int i = 0; i < gs.length; i++) {
				//키가 허용키(110cm)이상이면 허용인원 배열에 들어가기
				if(gs[i].getHeight() > RollerCoaster.CUTHEIGHT) {
					 onBoard[count++] = gs[i];
				}
			}
			//배열 크기를 넘어가게 된다면???
		} catch(ArrayIndexOutOfBoundsException e) {
			//e.getMessage() = Index 2 out of bounds for length 2
			//substring 사용해서 인덱스 번호 빼주기
			String str = "문제가 발생한 해당 배열의 인덱스 번호 : " + e.getMessage().substring(6, 8);

			System.out.println(str);
			
		}finally {
			System.out.println("인원이 가득 찼습니다. 다음 차례를 기다리세요");
			System.out.println("이번 차례 탑승 명단");
			
			for(int i = 0; i < count -1; i++) {//count 크기가 3 --> 2로 만들기 왜? 후위연산자여서 3인상태임 배열은 2개까지 들어가니까 -1해서 2로 만들어줘야함
				System.out.println("이름 : " + onBoard[i].getName() + ", 키 : " + onBoard[i].getHeight()); // 탑승자 각각의 이름, 키를 출력하고
			}
			System.out.println("탑승자 요금 : " + RollerCoaster.PRICE * 2);
		}
	
	}
	
}

